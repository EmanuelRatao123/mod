package com.emanuel.naturaldisasters;

import net.minecraftforge.fml.common.Mod;

@Mod("naturaldisasters")
public class NaturalDisastersMod {
    public NaturalDisastersMod() {}
}
