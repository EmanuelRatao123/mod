package com.emanuel.naturaldisasters;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.block.Blocks;
import net.minecraft.command.CommandSource;
import net.minecraft.command.Commands;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningBoltEntity;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.world.Explosion;
import net.minecraft.world.gen.Heightmap;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.util.text.StringTextComponent;
import java.util.Random;

@Mod.EventBusSubscriber(modid = "naturaldisasters")
public class DisasterCommands {
    private static final Random R = new Random();

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSource> d = event.getDispatcher();
        d.register(Commands.literal("disaster")
            .then(Commands.literal("help").executes(c -> {
                c.getSource().sendSuccess(new StringTextComponent(
                    "Use /disaster start <1-10> [radius]. 1 Tornado, 2 Earthquake, 3 Meteor Shower, " +
                    "4 Lightning Storm, 5 Flood, 6 Wildfire, 7 Sandstorm, 8 Blizzard, " +
                    "9 Volcanic Eruption, 10 Sinkholes. Try /disaster start 3 20."), false);
                return 1;
            }))
            .then(Commands.literal("start")
                .then(Commands.argument("id", IntegerArgumentType.integer(1,10))
                    .executes(c -> run(c.getSource(), IntegerArgumentType.getInteger(c,"id"), 15))
                    .then(Commands.argument("radius", IntegerArgumentType.integer(5,30))
                        .executes(c -> run(c.getSource(), IntegerArgumentType.getInteger(c,"id"),
                            IntegerArgumentType.getInteger(c,"radius")))))));
    }

    private static int rand(int r) { return R.nextInt(r * 2 + 1) - r; }

    private static int run(CommandSource s, int id, int r) {
        ServerWorld w = s.getLevel();
        BlockPos center = new BlockPos(s.getPosition());
        String[] names = {"","Tornado","Earthquake","Meteor Shower","Lightning Storm","Flood",
            "Wildfire","Sandstorm","Blizzard","Volcanic Eruption","Sinkholes"};
        s.sendSuccess(new StringTextComponent("Disaster started: " + names[id]), true);
        switch(id) {
            case 1: // Tornado: cloud funnel + damage
                for(int i=0;i<30;i++) {
                    int x=center.getX()+rand(r), z=center.getZ()+rand(r), y=center.getY()+R.nextInt(12);
                    w.sendParticles(ParticleTypes.CLOUD,x+.5,y+.5,z+.5,18,1.2,2,1.2,.03);
                }
                hurt(w,center,r,3); break;
            case 2: // Earthquake: cracks and rumble particles
                for(int i=0;i<r*3;i++) {
                    int x=center.getX()+rand(r),z=center.getZ()+rand(r);
                    BlockPos p=w.getHeight(Heightmap.Type.MOTION_BLOCKING,new BlockPos(x,0,z));
                    w.sendParticles(ParticleTypes.CLOUD,x+.5,p.getY()+.2,z+.5,12,.8,.2,.8,.02);
                    if(R.nextInt(5)==0 && w.isEmptyBlock(p)) w.setBlock(p,Blocks.COBBLESTONE.defaultBlockState(),3);
                }
                hurt(w,center,r,2); break;
            case 3: // Meteor shower
                for(int i=0;i<Math.max(5,r/2);i++) {
                    int x=center.getX()+rand(r),z=center.getZ()+rand(r);
                    BlockPos p=w.getHeight(Heightmap.Type.MOTION_BLOCKING,new BlockPos(x,0,z));
                    w.sendParticles(ParticleTypes.FLAME,x+.5,p.getY()+5,z+.5,45,.7,2,.7,.02);
                    w.explode(null,x+.5,p.getY()+1,z+.5,1.5F,Explosion.Mode.BREAK);
                } break;
            case 4: // Lightning storm
                for(int i=0;i<r;i++) {
                    BlockPos p=w.getHeight(Heightmap.Type.MOTION_BLOCKING,
                        new BlockPos(center.getX()+rand(r),0,center.getZ()+rand(r)));
                    LightningBoltEntity bolt=EntityType.LIGHTNING_BOLT.create(w);
                    if(bolt!=null){bolt.moveTo(p.getX()+.5,p.getY(),p.getZ()+.5);w.addFreshEntity(bolt);}
                } break;
            case 5: // Flood
                for(int x=-r;x<=r;x++) for(int z=-r;z<=r;z++) if(x*x+z*z<=r*r && R.nextInt(3)==0) {
                    BlockPos p=w.getHeight(Heightmap.Type.MOTION_BLOCKING,
                        new BlockPos(center.getX()+x,0,center.getZ()+z));
                    if(p.getY()>1) w.setBlock(p,Blocks.WATER.defaultBlockState(),3);
                } break;
            case 6: // Wildfire
                for(int i=0;i<r*2;i++) {
                    int x=center.getX()+rand(r),z=center.getZ()+rand(r);
                    BlockPos p=w.getHeight(Heightmap.Type.MOTION_BLOCKING,new BlockPos(x,0,z));
                    if(w.isEmptyBlock(p) && w.getBlockState(p.below()).getMaterial().isSolid())
                        w.setBlock(p,Blocks.FIRE.defaultBlockState(),3);
                    w.sendParticles(ParticleTypes.SMOKE,x+.5,p.getY()+.3,z+.5,8,.5,.4,.5,.01);
                } break;
            case 7: // Sandstorm
                for(int i=0;i<r*3;i++) {
                    int x=center.getX()+rand(r),z=center.getZ()+rand(r);
                    BlockPos p=w.getHeight(Heightmap.Type.MOTION_BLOCKING,new BlockPos(x,0,z));
                    w.sendParticles(ParticleTypes.CLOUD,x+.5,p.getY()+3,z+.5,16,2,1,2,.04);
                }
                hurt(w,center,r,1); break;
            case 8: // Blizzard
                for(int i=0;i<r*3;i++) {
                    int x=center.getX()+rand(r),z=center.getZ()+rand(r);
                    BlockPos p=w.getHeight(Heightmap.Type.MOTION_BLOCKING,new BlockPos(x,0,z));
                    w.sendParticles(ParticleTypes.SNOWFLAKE,x+.5,p.getY()+3,z+.5,20,2,2,2,.04);
                    if(w.isEmptyBlock(p) && w.getBlockState(p.below()).getMaterial().isSolid())
                        w.setBlock(p,Blocks.SNOW.defaultBlockState(),3);
                } break;
            case 9: // Volcanic eruption
                for(int i=0;i<Math.max(6,r/2);i++) {
                    int x=center.getX()+rand(r),z=center.getZ()+rand(r);
                    BlockPos p=w.getHeight(Heightmap.Type.MOTION_BLOCKING,new BlockPos(x,0,z));
                    w.sendParticles(ParticleTypes.LAVA,x+.5,p.getY()+1,z+.5,25,1,1,1,.02);
                    if(R.nextInt(3)==0) w.setBlock(p,Blocks.LAVA.defaultBlockState(),3);
                    if(R.nextInt(3)==0) w.setBlock(p.above(),Blocks.MAGMA_BLOCK.defaultBlockState(),3);
                }
                hurt(w,center,r,2); break;
            case 10: // Sinkholes
                for(int i=0;i<Math.max(4,r/3);i++) {
                    int x=center.getX()+rand(r),z=center.getZ()+rand(r);
                    BlockPos p=w.getHeight(Heightmap.Type.MOTION_BLOCKING,new BlockPos(x,0,z));
                    for(int y=0;y<4;y++) w.setBlock(p.below(y),Blocks.AIR.defaultBlockState(),3);
                    w.sendParticles(ParticleTypes.CLOUD,x+.5,p.getY(),z+.5,20,1,.5,1,.02);
                } break;
        }
        return 1;
    }

    private static void hurt(ServerWorld w, BlockPos c, int r, float damage) {
        w.getEntities(null,new AxisAlignedBB(c).inflate(r,8,r)).forEach(e -> {
            if(e instanceof net.minecraft.entity.LivingEntity &&
                e.distanceToSqr(c.getX()+.5,c.getY()+.5,c.getZ()+.5)<r*r)
                ((net.minecraft.entity.LivingEntity)e).hurt(
                    net.minecraft.util.DamageSource.GENERIC,damage);
        });
    }
}
